import { Loader } from "@mantine/core";

export default function () {
  return <Loader size={10} />;
}

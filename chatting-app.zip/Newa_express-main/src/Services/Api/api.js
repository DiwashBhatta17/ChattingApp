const baseURL = "http://localhost:8081/";

export default baseURL;
